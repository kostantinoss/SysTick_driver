#ifndef SYSTICK_H
#define SYSTICK_H


void InitSysTick();
void SysTickDelay(int delay_ms);
void DeInitSysTick();


#endif /* SYSTICK_H */
