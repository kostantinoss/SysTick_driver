#ifndef MAIN_H
#define MAIN_H

#include "stm32f4xx.h"

#define LED		5
#define GPIO	GPIOA

#endif /* MAIN_H */
